/**
 * Digital 7-Segment Clock Script (BeBeam 규격 준수)
 * - 폰트 비의존: GLYPH_PATHS(SVG 벡터) 기반 렌더링
 * - 12시간 / 24시간 토글 지원
 * - AM / PM 램프 방식 표시 (상시 자리 유지, 활성 램프 점등)
 * - 배경 클릭 시 색상 순환 (흰색 -> 노랑 -> 연두 -> 빨강)
 * - 시계판 클릭 시 12H / 24H 전환 (이벤트 전파 중단으로 색상 변경과 분리)
 * - 카시오 시계 정각 시보 (Web Audio API 2048Hz "삐-삑!" Chime)
 * - 화면 켜짐 유지 (Always On / Screen Wake Lock API)
 * - BeBeam 저장소 규칙 준수: localStorage 접두사 'digital-clock:' 및 try/catch 보호
 */

document.addEventListener('DOMContentLoaded', () => {
  // BeBeam 저장소 키 접두사
  const STORAGE_PREFIX = 'digital-clock:';

  // 1. 색상 테마 정의 (흰색, 노랑, 연두, 빨강)
  const COLORS = [
    { name: '흰색', id: 'white', hex: '#ffffff' },
    { name: '노랑', id: 'yellow', hex: '#ffe600' },
    { name: '연두', id: 'lime', hex: '#39ff14' },
    { name: '빨강', id: 'red', hex: '#ff2a2a' }
  ];

  let currentColorIndex = 0; // 0: 흰색 (기본값)
  let is24Hour = false;      // false: 12시간제 (기본값)
  let isAlwaysOn = false;    // false: 화면 켜짐 유지 해제 (기본값)
  let wakeLockSentinel = null;
  let lastChimeHour = -1;

  // DOM 요소 참조
  const clockBoard = document.getElementById('clock-board');
  const helpBtn = document.getElementById('help-btn');
  const btnAlwaysOn = document.getElementById('btn-always-on');

  // AM / PM 램프 DOM
  const lampAM = document.getElementById('lamp-am');
  const lampPM = document.getElementById('lamp-pm');
  const pathAM = document.getElementById('path-am');
  const pathPM = document.getElementById('path-pm');

  // 세그먼트 전경 & 배경 DOM
  const fgH1 = document.getElementById('fg-h1');
  const fgH2 = document.getElementById('fg-h2');
  const fgC1 = document.getElementById('fg-c1');
  const fgM1 = document.getElementById('fg-m1');
  const fgM2 = document.getElementById('fg-m2');
  const fgC2 = document.getElementById('fg-c2');
  const fgS1 = document.getElementById('fg-s1');
  const fgS2 = document.getElementById('fg-s2');

  const bgH1 = document.getElementById('bg-h1');
  const bgH2 = document.getElementById('bg-h2');
  const bgC1 = document.getElementById('bg-c1');
  const bgM1 = document.getElementById('bg-m1');
  const bgM2 = document.getElementById('bg-m2');
  const bgC2 = document.getElementById('bg-c2');
  const bgS1 = document.getElementById('bg-s1');
  const bgS2 = document.getElementById('bg-s2');

  // -------------------------------------------------------------
  // [Web Audio API] 카시오 시계 정각 시보 (Hourly Chime)
  // -------------------------------------------------------------
  let audioCtx = null;
  function getAudioContext() {
    if (!audioCtx) {
      const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
      if (AudioCtxClass) {
        audioCtx = new AudioCtxClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }
    return audioCtx;
  }

  // 사용자 첫 제스처 시 오디오 컨텍스트 언락
  function unlockAudio() {
    getAudioContext();
  }
  window.addEventListener('click', unlockAudio, { once: true });
  window.addEventListener('keydown', unlockAudio, { once: true });
  window.addEventListener('touchstart', unlockAudio, { once: true });

  // 카시오 시계 특유의 2048Hz "삐-삑!" 정각 비프음
  function playCasioHourlyBeep() {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const freq = 2048; // 카시오 피에조 부저 표준 주파수

    function createBeep(startTime, duration) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'square'; // 전자시계 부저 특유의 톤
      osc.frequency.setValueAtTime(freq, startTime);

      // 팝 노이즈 방지용 엔벨로프
      gain.gain.setValueAtTime(0.0001, startTime);
      gain.gain.exponentialRampToValueAtTime(0.18, startTime + 0.005);
      gain.gain.setValueAtTime(0.18, startTime + duration - 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + duration);
    }

    // 비프 1: 0초 ~ 0.07초
    createBeep(now, 0.07);
    // 비프 2: 0.13초 ~ 0.20초 ("삐-삑!")
    createBeep(now + 0.13, 0.07);
  }

  // -------------------------------------------------------------
  // [Screen Wake Lock API] 화면 켜짐 유지 (Always On)
  // -------------------------------------------------------------
  async function requestWakeLock() {
    if ('wakeLock' in navigator) {
      try {
        wakeLockSentinel = await navigator.wakeLock.request('screen');
      } catch (err) {
        console.warn('Wake Lock request failed:', err);
      }
    }
  }

  function releaseWakeLock() {
    if (wakeLockSentinel) {
      wakeLockSentinel.release().catch(() => {});
      wakeLockSentinel = null;
    }
  }

  // 탭 전환 후 앱 복귀 시 WakeLock 재요청
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && isAlwaysOn) {
      requestWakeLock();
    }
  });

  function setAlwaysOn(enable) {
    isAlwaysOn = enable;
    if (isAlwaysOn) {
      btnAlwaysOn.classList.add('is-active');
      requestWakeLock();
    } else {
      btnAlwaysOn.classList.remove('is-active');
      releaseWakeLock();
    }
    // localStorage 저장
    try {
      localStorage.setItem(STORAGE_PREFIX + 'always-on', JSON.stringify(isAlwaysOn));
    } catch (e) {
      /* 저장 실패 시 무시 */
    }
  }

  // -------------------------------------------------------------
  // 배경 7세그먼트(8) 및 콜론 경로 초기화
  // -------------------------------------------------------------
  function initBackgroundSegments() {
    const bg8 = GLYPH_PATHS['8_bg'];
    const colonPath = GLYPH_PATHS[':'];

    bgH1.setAttribute('d', bg8);
    bgH2.setAttribute('d', bg8);
    bgM1.setAttribute('d', bg8);
    bgM2.setAttribute('d', bg8);
    bgS1.setAttribute('d', bg8);
    bgS2.setAttribute('d', bg8);

    bgC1.setAttribute('d', colonPath);
    bgC2.setAttribute('d', colonPath);

    fgC1.setAttribute('d', colonPath);
    fgC2.setAttribute('d', colonPath);

    // AM, PM 램프 경로 설정
    pathAM.setAttribute('d', GLYPH_PATHS['AM']);
    pathPM.setAttribute('d', GLYPH_PATHS['PM']);
  }

  // -------------------------------------------------------------
  // 시계 시간 업데이트 및 정각 시보 체크
  // -------------------------------------------------------------
  function updateClock() {
    const now = new Date();
    const rawHours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    // 1시간마다 카시오 시보 비프음 재생 (00분 00초에 1회)
    if (minutes === 0 && seconds === 0 && lastChimeHour !== rawHours) {
      lastChimeHour = rawHours;
      playCasioHourlyBeep();
    } else if (minutes !== 0) {
      lastChimeHour = -1; // 다음 정각 대비 리셋
    }

    const isPM = rawHours >= 12;
    let displayHours;

    if (is24Hour) {
      displayHours = rawHours;
      // 24시간 모드: AM/PM 램프 모두 소등 (자리는 차지하고 램프는 OFF)
      lampAM.classList.remove('is-lit');
      lampPM.classList.remove('is-lit');
    } else {
      // 12시간 모드: 12시 표시 및 01~12 형식
      displayHours = rawHours % 12;
      if (displayHours === 0) displayHours = 12;

      // 램프 점등 제어: AM일 때 AM 램프 ON, PM일 때 PM 램프 ON
      if (isPM) {
        lampAM.classList.remove('is-lit');
        lampPM.classList.add('is-lit');
      } else {
        lampAM.classList.add('is-lit');
        lampPM.classList.remove('is-lit');
      }
    }

    // 두 자리 문자열 포맷팅 (04:00:00, 11:00:04 등)
    const hStr = String(displayHours).padStart(2, '0');
    const mStr = String(minutes).padStart(2, '0');
    const sStr = String(seconds).padStart(2, '0');

    // SVG 전경 숫자 경로 동적 갱신
    fgH1.setAttribute('d', GLYPH_PATHS[hStr[0]]);
    fgH2.setAttribute('d', GLYPH_PATHS[hStr[1]]);
    fgM1.setAttribute('d', GLYPH_PATHS[mStr[0]]);
    fgM2.setAttribute('d', GLYPH_PATHS[mStr[1]]);
    fgS1.setAttribute('d', GLYPH_PATHS[sStr[0]]);
    fgS2.setAttribute('d', GLYPH_PATHS[sStr[1]]);
  }

  // -------------------------------------------------------------
  // 색상 순환 변경 함수 (흰색 -> 노랑 -> 연두 -> 빨강)
  // -------------------------------------------------------------
  function cycleColor() {
    currentColorIndex = (currentColorIndex + 1) % COLORS.length;
    applyColor(currentColorIndex);
    try {
      localStorage.setItem(STORAGE_PREFIX + 'color-index', JSON.stringify(currentColorIndex));
    } catch (e) {}
  }

  function applyColor(index) {
    const color = COLORS[index];
    if (color.id === 'white') {
      document.body.removeAttribute('data-color');
    } else {
      document.body.setAttribute('data-color', color.id);
    }
  }

  // -------------------------------------------------------------
  // 이벤트 핸들러 설정
  // -------------------------------------------------------------
  // (1) 시계판 밖의 빈 공간 클릭 -> 색상 순환
  document.body.addEventListener('click', () => {
    cycleColor();
  });

  // (2) Always On 토글 버튼 클릭 (이벤트 버블링 차단)
  if (btnAlwaysOn) {
    btnAlwaysOn.addEventListener('click', (e) => {
      e.stopPropagation();
      getAudioContext();
      setAlwaysOn(!isAlwaysOn);
    });
    btnAlwaysOn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        e.stopPropagation();
        getAudioContext();
        setAlwaysOn(!isAlwaysOn);
      }
    });
  }

  // (3) 좌측 상단 (?) 버튼 클릭 시 이벤트 버블링 차단 (배경 클릭 색상 변경 방지)
  if (helpBtn) {
    helpBtn.addEventListener('click', (e) => {
      e.stopPropagation();
    });
  }

  // (4) 시계판 클릭 -> 12시간 / 24시간 토글 (이벤트 버블링 차단)
  clockBoard.addEventListener('click', (e) => {
    e.stopPropagation();
    getAudioContext();
    is24Hour = !is24Hour;
    try {
      localStorage.setItem(STORAGE_PREFIX + 'mode-24h', JSON.stringify(is24Hour));
    } catch (e) {}
    updateClock();
  });

  // 키보드 접근성 지원 (Enter / Space로 시계판 토글, C키로 색상 변경)
  clockBoard.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      e.stopPropagation();
      getAudioContext();
      is24Hour = !is24Hour;
      try {
        localStorage.setItem(STORAGE_PREFIX + 'mode-24h', JSON.stringify(is24Hour));
      } catch (e) {}
      updateClock();
    }
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'c' || e.key === 'C') {
      cycleColor();
    }
  });

  // -------------------------------------------------------------
  // 초기화 및 저장된 설정 복원
  // -------------------------------------------------------------
  initBackgroundSegments();

  // localStorage 복원 (BeBeam 규격)
  try {
    const savedColor = localStorage.getItem(STORAGE_PREFIX + 'color-index');
    if (savedColor !== null) {
      const idx = JSON.parse(savedColor);
      if (idx >= 0 && idx < COLORS.length) currentColorIndex = idx;
    }

    const savedMode = localStorage.getItem(STORAGE_PREFIX + 'mode-24h');
    if (savedMode !== null) {
      is24Hour = JSON.parse(savedMode);
    }

    const savedAlwaysOn = localStorage.getItem(STORAGE_PREFIX + 'always-on');
    if (savedAlwaysOn !== null) {
      setAlwaysOn(JSON.parse(savedAlwaysOn));
    }
  } catch (e) {
    console.warn('localStorage read error:', e);
  }

  // URL 쿼리 파라미터 지원 (테스트 및 특정 모드 직접 링크용)
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has('color')) {
    const pColor = parseInt(urlParams.get('color'), 10);
    if (!isNaN(pColor) && pColor >= 0 && pColor < COLORS.length) {
      currentColorIndex = pColor;
    }
  }
  if (urlParams.has('mode')) {
    is24Hour = urlParams.get('mode') === '24';
  }
  if (urlParams.has('alwayson')) {
    setAlwaysOn(urlParams.get('alwayson') === 'true');
  }

  applyColor(currentColorIndex);
  updateClock();

  // 매 100ms마다 정확한 초 단위 갱신
  setInterval(updateClock, 100);
});
