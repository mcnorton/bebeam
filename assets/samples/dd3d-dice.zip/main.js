// 3차원 픽셀 주사위 (서버 없이 로컬 실행 지원)
(function () {
  'use strict';

  // 6면 정의: 마주보는 면의 합 = 7
  // +Z(1), -Z(6), +Y(2), -Y(5), +X(3), -X(4)
  const FACES = [
    {
      val: 1,
      norm: [0, 0, 1],
      u: [1, 0, 0],
      v: [0, 1, 0],
      pips: [[0, 0]],
      pipR: 0.28
    },
    {
      val: 6,
      norm: [0, 0, -1],
      u: [-1, 0, 0],
      v: [0, 1, 0],
      pips: [
        [-0.46, -0.52], [0.46, -0.52],
        [-0.46, 0.0],   [0.46, 0.0],
        [-0.46, 0.52],  [0.46, 0.52]
      ],
      pipR: 0.16
    },
    {
      val: 2,
      norm: [0, 1, 0],
      u: [1, 0, 0],
      v: [0, 0, -1],
      pips: [[-0.46, -0.46], [0.46, 0.46]],
      pipR: 0.18
    },
    {
      val: 5,
      norm: [0, -1, 0],
      u: [1, 0, 0],
      v: [0, 0, 1],
      pips: [
        [-0.48, -0.48], [0.48, -0.48],
        [0, 0],
        [-0.48, 0.48],  [0.48, 0.48]
      ],
      pipR: 0.17
    },
    {
      val: 3,
      norm: [1, 0, 0],
      u: [0, 1, 0],
      v: [0, 0, 1],
      pips: [[-0.5, -0.5], [0, 0], [0.5, 0.5]],
      pipR: 0.17
    },
    {
      val: 4,
      norm: [-1, 0, 0],
      u: [0, -1, 0],
      v: [0, 0, 1],
      pips: [
        [-0.46, -0.46], [0.46, -0.46],
        [-0.46, 0.46],  [0.46, 0.46]
      ],
      pipR: 0.17
    }
  ];

  const PALETTES = {
    red: {
      id: 'red',
      name: '빨강',
      face: [255, 0, 77],
      bevel: [255, 119, 168],
      shade: [126, 37, 83],
      edge: [45, 10, 30],
      pip: '#ffffff',
      pipOne: '#ffec27'
    },
    blue: {
      id: 'blue',
      name: '파랑',
      face: [41, 173, 255],
      bevel: [131, 219, 252],
      shade: [29, 43, 83],
      edge: [12, 20, 44],
      pip: '#ffffff',
      pipOne: '#ffec27'
    },
    yellow: {
      id: 'yellow',
      name: '노랑',
      face: [255, 236, 39],
      bevel: [255, 241, 232],
      shade: [171, 82, 54],
      edge: [56, 26, 16],
      pip: '#181425',
      pipOne: '#ff004d'
    }
  };

  // --- 쿼터니언 연산 ---
  function qNorm(q) {
    const l = Math.hypot(q[0], q[1], q[2], q[3]) || 1;
    return [q[0] / l, q[1] / l, q[2] / l, q[3] / l];
  }

  function qMul(a, b) {
    return [
      a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
      a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
      a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
      a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]
    ];
  }

  function qAxisAngle(ax, ay, az, angle) {
    const l = Math.hypot(ax, ay, az) || 1;
    const h = angle * 0.5;
    const s = Math.sin(h) / l;
    return [Math.cos(h), ax * s, ay * s, az * s];
  }

  function qEuler(rx, ry, rz) {
    const qx = qAxisAngle(1, 0, 0, rx);
    const qy = qAxisAngle(0, 1, 0, ry);
    const qz = qAxisAngle(0, 0, 1, rz);
    return qNorm(qMul(qz, qMul(qy, qx)));
  }

  function qRotate(v, q) {
    const qw = q[0], qx = q[1], qy = q[2], qz = q[3];
    const vx = v[0], vy = v[1], vz = v[2];
    const tx = 2 * (qy * vz - qz * vy);
    const ty = 2 * (qz * vx - qx * vz);
    const tz = 2 * (qx * vy - qy * vx);
    return [
      vx + qw * tx + (qy * tz - qz * ty),
      vy + qw * ty + (qz * tx - qx * tz),
      vz + qw * tz + (qx * ty - qy * tx)
    ];
  }

  function qSlerp(a, b, t) {
    let bx = b[0], by = b[1], bz = b[2], bw = b[3];
    let dot = a[0] * bx + a[1] * by + a[2] * bz + a[3] * bw;
    if (dot < 0) {
      dot = -dot;
      bx = -bx; by = -by; bz = -bz; bw = -bw;
    }
    if (dot > 0.999) {
      return qNorm([
        a[0] + t * (bx - a[0]),
        a[1] + t * (by - a[1]),
        a[2] + t * (bz - a[2]),
        a[3] + t * (bw - a[3])
      ]);
    }
    const theta0 = Math.acos(Math.min(1, dot));
    const theta = theta0 * t;
    const s0 = Math.cos(theta) - dot * Math.sin(theta) / Math.sin(theta0);
    const s1 = Math.sin(theta) / Math.sin(theta0);
    return qNorm([
      s0 * a[0] + s1 * bx,
      s0 * a[1] + s1 * by,
      s0 * a[2] + s1 * bz,
      s0 * a[3] + s1 * bw
    ]);
  }

  // 바닥면에 딱 닿았을 때 카메라(+Z) 방향을 향하는 윗면 찾기
  function getTopAlignedState(q) {
    let bestFace = FACES[0];
    let bestZ = -Infinity;
    for (const f of FACES) {
      const wn = qRotate(f.norm, q);
      if (wn[2] > bestZ) {
        bestZ = wn[2];
        bestFace = f;
      }
    }
    const wn = qRotate(bestFace.norm, q);
    const cx = -wn[1], cy = wn[0];
    const clen = Math.hypot(cx, cy);
    let qAlign = [1, 0, 0, 0];
    if (clen > 1e-4) {
      const angle = Math.acos(Math.max(-1, Math.min(1, wn[2])));
      qAlign = qAxisAngle(cx / clen, cy / clen, 0, angle);
    } else if (wn[2] < 0) {
      qAlign = qAxisAngle(1, 0, 0, Math.PI);
    }
    const qFlat = qNorm(qMul(qAlign, q));
    const wu = qRotate(bestFace.u, qFlat);
    const curYaw = Math.atan2(wu[1], wu[0]);
    const snapYaw = Math.round(curYaw / (Math.PI * 0.5)) * (Math.PI * 0.5);
    const qYaw = qAxisAngle(0, 0, 1, snapYaw - curYaw);
    return {
      face: bestFace,
      targetQ: qNorm(qMul(qYaw, qFlat))
    };
  }

  // --- 레트로 사운드 (Web Audio API) ---
  let audioCtx = null;
  function getAudio() {
    if (!audioCtx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) audioCtx = new AC();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume().catch(function () {});
    }
    return audioCtx;
  }

  function playTone(freq, dur, type, gainVal, slide) {
    const ac = getAudio();
    if (!ac) return;
    try {
      const osc = ac.createOscillator();
      const g = ac.createGain();
      const t = ac.currentTime;
      osc.type = type || 'square';
      osc.frequency.setValueAtTime(freq, t);
      if (slide) {
        osc.frequency.exponentialRampToValueAtTime(Math.max(30, slide), t + dur);
      }
      g.gain.setValueAtTime(gainVal || 0.08, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      osc.connect(g);
      g.connect(ac.destination);
      osc.start(t);
      osc.stop(t + dur);
    } catch (e) {}
  }

  function sfxSelect(on) {
    if (on) {
      playTone(440, 0.05, 'square', 0.08, 660);
      setTimeout(function () { playTone(880, 0.06, 'square', 0.08); }, 40);
    } else {
      playTone(440, 0.05, 'square', 0.06, 260);
    }
  }

  function sfxStart() {
    [330, 440, 554, 660].forEach(function (f, i) {
      setTimeout(function () { playTone(f, 0.06, 'square', 0.09); }, i * 45);
    });
  }

  function sfxWall() {
    playTone(180 + Math.random() * 120, 0.05, 'square', 0.1, 80);
  }

  function sfxFloor() {
    playTone(120 + Math.random() * 60, 0.035, 'triangle', 0.07, 70);
  }

  function sfxZoom() {
    [523, 659, 784, 1046].forEach(function (f, i) {
      setTimeout(function () { playTone(f, 0.08, 'square', 0.07); }, i * 50);
    });
  }

  // --- 캔버스 및 DOM 참조 ---
  const canvas = document.getElementById('dice-canvas');
  const ctx = canvas.getContext('2d');
  const btnPlay = document.getElementById('btn-play');
  const btnHome = document.getElementById('btn-home');
  const selectHeader = document.getElementById('select-header');
  const selectLabel = document.getElementById('select-label');
  const playArea = document.getElementById('play-area');

  let width = window.innerWidth;
  let height = window.innerHeight;
  let dpr = window.devicePixelRatio || 1;
  let baseRadius = 36;

  let mode = 'SELECT'; // 'SELECT' | 'PLAY'
  let phase = 'IDLE'; // 'ROLLING' | 'SETTLED'

  // 주사위 3개 (빨강, 파랑, 노랑) - 기본값: 빨강+파랑 2개만 선택
  const DICE_KEYS = ['red', 'blue', 'yellow'];
  const dice = DICE_KEYS.map(function (k, idx) {
    const isDefaultSelected = (idx < 2); // 4번 요구사항: 빨강(0), 파랑(1)만 기본 선택
    return {
      key: k,
      palette: PALETTES[k],
      selected: isDefaultSelected,
      x: 0,
      y: 0,
      z: 0, // 바닥면 높이 (공중으로 뜨지 않고 바닥면을 구름)
      vx: 0,
      vy: 0,
      q: qEuler(0.45 + idx * 0.35, -0.55 + idx * 0.4, 0.25),
      targetQ: [1, 0, 0, 0],
      // 3번 요구사항: 선택된 주사위는 +25%(1.25), 비선택은 -10%(0.90)
      scale: isDefaultSelected ? 1.25 : 0.90,
      targetScale: isDefaultSelected ? 1.25 : 0.90,
      alpha: isDefaultSelected ? 1.0 : 0.32,
      targetAlpha: isDefaultSelected ? 1.0 : 0.32,
      settled: false,
      topFace: FACES[idx * 2],
      idleOffset: idx * 2.0
    };
  });

  const particles = [];
  const wallSparks = [];

  function spawnParticles(x, y, rgb, count) {
    for (let i = 0; i < (count || 5); i++) {
      const a = Math.random() * Math.PI * 2;
      const spd = 40 + Math.random() * 100;
      particles.push({
        x: x,
        y: y,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        color: 'rgb(' + rgb.join(',') + ')',
        life: 0.28,
        maxLife: 0.28
      });
    }
  }

  function spawnWallSpark(side, pos, rgb) {
    wallSparks.push({
      side: side,
      pos: pos,
      color: 'rgb(' + rgb.join(',') + ')',
      life: 0.18
    });
  }

  function getBounds(r) {
    const margin = 20;
    return {
      left: margin + r,
      right: width - margin - r,
      top: (mode === 'PLAY' ? 76 : margin) + r,
      bottom: (mode === 'PLAY' ? 24 : 96) + r
    };
  }

  function resize() {
    width = window.innerWidth;
    height = window.innerHeight;
    dpr = window.devicePixelRatio || 1;

    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';

    const minDim = Math.min(width, height);
    baseRadius = Math.round(Math.max(26, Math.min(48, minDim * 0.088)));

    if (mode === 'SELECT') {
      layoutSelectDice();
    } else {
      dice.forEach(function (d) {
        if (!d.selected) return;
        const b = getBounds(baseRadius * d.scale);
        d.x = Math.max(b.left, Math.min(b.right, d.x));
        d.y = Math.max(b.top, Math.min(height - b.bottom, d.y));
      });
    }
  }

  function layoutSelectDice() {
    const cx = width * 0.5;
    const cy = height * 0.48;
    const spacing = Math.min(width * 0.28, baseRadius * 3.4);

    dice.forEach(function (d, idx) {
      d.x = cx + (idx - 1) * spacing;
      d.y = cy;
      d.z = 0;
      d.vx = 0;
      d.vy = 0;
    });

    // 1번 요구사항: 화면 위(상단)와 주사위 중간에 2차원 타이틀 위치
    if (selectHeader) {
      const diceTop = cy - baseRadius * 1.25;
      const headerY = Math.round(diceTop * 0.5);
      selectHeader.style.top = headerY + 'px';
    }

    // 2번 요구사항: 주사위 아래에 "SELECT DICE" 레이블 배치
    if (selectLabel) {
      const diceBottom = cy + baseRadius * 1.25;
      const labelY = Math.round(diceBottom + Math.max(18, baseRadius * 0.6));
      selectLabel.style.top = labelY + 'px';
    }
  }

  // --- 1. 주사위 탭: 진하게/반투명 토글 (적어도 1개는 선택 유지) ---
  function toggleDie(die) {
    if (mode !== 'SELECT') return;

    const selectedCount = dice.filter(function (d) { return d.selected; }).length;

    // 시작화면에 적어도 하나는 선택되어야 함 (1개 남았을 때는 취소 불가)
    if (die.selected && selectedCount <= 1) {
      playTone(200, 0.05, 'square', 0.06);
      spawnParticles(die.x, die.y, [255, 255, 255], 3);
      return;
    }

    die.selected = !die.selected;
    die.targetAlpha = die.selected ? 1.0 : 0.32;
    // 3번 요구사항: 선택된 주사위는 25% 더 크게(1.25), 비선택은 10% 작게(0.90)
    die.targetScale = die.selected ? 1.25 : 0.90;

    sfxSelect(die.selected);
    spawnParticles(die.x, die.y, die.palette.bevel, die.selected ? 8 : 3);
  }

  // --- 2. (>) PLAY: 바닥면을 구르면서 섞임 ---
  function startPlay() {
    let active = dice.filter(function (d) { return d.selected; });
    if (active.length === 0) {
      dice.forEach(function (d) {
        d.selected = true;
        d.alpha = 1.0;
        d.targetAlpha = 1.0;
      });
      active = dice;
    }

    mode = 'PLAY';
    playArea.hidden = true;
    selectHeader.hidden = true;
    if (selectLabel) selectLabel.hidden = true;
    btnHome.hidden = false;

    sfxStart();
    rollAllDice(null);
  }

  // --- 4. 세 주사위 중 하나만 스와이프해도 모두 바닥면을 구름 ---
  function rollAllDice(swipeDir) {
    phase = 'ROLLING';
    const active = dice.filter(function (d) { return d.selected; });
    const count = active.length;

    const baseSpeed = Math.max(width, height) * 1.45;
    let mainAngle = -Math.PI * 0.5; // 기본 위쪽
    let launchSpeed = baseSpeed;

    if (swipeDir) {
      mainAngle = Math.atan2(swipeDir.vy, swipeDir.vx);
      const rawSpeed = Math.hypot(swipeDir.vx, swipeDir.vy);
      launchSpeed = Math.max(baseSpeed, Math.min(rawSpeed * 1.3, baseSpeed * 2.2));
    } else {
      mainAngle = Math.random() * Math.PI * 2;
    }

    active.forEach(function (d, idx) {
      d.settled = false;
      d.scale = 1.0;
      d.targetScale = 1.0;
      d.alpha = 1.0;
      d.targetAlpha = 1.0;
      d.z = 0; // 공중을 떠서 구르는 게 아니라 바닥면을 구름

      // 주사위들이 고르게 퍼져 벽면에 튕기도록 각도 분산
      const spread = (idx - (count - 1) * 0.5) * 0.42;
      const angle = mainAngle + spread + (Math.random() - 0.5) * 0.2;
      const spd = launchSpeed * (0.88 + Math.random() * 0.25);

      d.vx = Math.cos(angle) * spd;
      d.vy = Math.sin(angle) * spd;
    });
  }

  // --- 5. 왼쪽 위 (Home) 버튼: 주사위 선택 메뉴 복귀 ---
  function returnToSelect() {
    mode = 'SELECT';
    phase = 'IDLE';
    playArea.hidden = false;
    selectHeader.hidden = false;
    if (selectLabel) selectLabel.hidden = false;
    btnHome.hidden = true;

    dice.forEach(function (d) {
      d.targetScale = d.selected ? 1.25 : 0.90;
      d.targetAlpha = d.selected ? 1.0 : 0.32;
      d.vx = 0;
      d.vy = 0;
      d.z = 0;
      d.settled = false;
    });

    layoutSelectDice();
    sfxSelect(true);
  }

  // --- 3. 회전 종료: 바닥면이 딱 닿아서 윗면이 2차원으로 확대 (기존 대비 50% 더 크게 = 3.0배) ---
  function onAllSettled() {
    phase = 'SETTLED';
    const active = dice.filter(function (d) { return d.selected; });

    active.forEach(function (d) {
      const topState = getTopAlignedState(d.q);
      d.topFace = topState.face;
      d.targetQ = topState.targetQ;
      // 기존 2.0배에서 50% 더 크게 확대 -> 3.0배
      d.targetScale = 3.0;
    });

    sfxZoom();
  }

  // 50% 더 커진 2차원 윗면들이 겹치지 않고 화면 안으로 들어오도록 부드럽게 분리
  function smoothSeparateZoomed(active, dt) {
    const rate = Math.min(1, dt * 9);
    for (let i = 0; i < active.length; i++) {
      const a = active[i];
      const ra = baseRadius * a.scale;
      const b = getBounds(ra);
      const tx = Math.max(b.left, Math.min(b.right, a.x));
      const ty = Math.max(b.top, Math.min(height - b.bottom, a.y));
      a.x += (tx - a.x) * rate;
      a.y += (ty - a.y) * rate;

      for (let j = i + 1; j < active.length; j++) {
        const c = active[j];
        const minDist = baseRadius * (a.scale + c.scale) * 1.05;
        let dx = c.x - a.x;
        let dy = c.y - a.y;
        let dist = Math.hypot(dx, dy);
        if (dist < minDist) {
          if (dist < 1e-3) { dx = 1; dy = 0; dist = 1; }
          // 화면 너비에 비해 주사위가 커서 3개가 일렬로 겹칠 경우 상하로 자연스럽게 분산 유도
          if (Math.abs(dy) < minDist * 0.35) {
            dy += (i % 2 === 0 ? 1 : -1) * 8;
            dist = Math.hypot(dx, dy);
          }
          const push = (minDist - dist) * 0.5 * rate;
          const nx = dx / dist, ny = dy / dist;
          a.x -= nx * push;
          a.y -= ny * push;
          c.x += nx * push;
          c.y += ny * push;
        }
      }
    }
  }

  // --- 바닥면 굴림 물리 업데이트 (공중에 뜨지 않고 바닥을 구름) ---
  function updatePhysics(dt) {
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;
      if (p.life <= 0) particles.splice(i, 1);
    }
    for (let i = wallSparks.length - 1; i >= 0; i--) {
      wallSparks[i].life -= dt;
      if (wallSparks[i].life <= 0) wallSparks.splice(i, 1);
    }

    if (mode === 'SELECT') {
      const now = performance.now() * 0.001;
      dice.forEach(function (d) {
        d.scale += (d.targetScale - d.scale) * Math.min(1, dt * 10);
        d.alpha += (d.targetAlpha - d.alpha) * Math.min(1, dt * 10);

        // 선택 메뉴에서는 입체감을 위해 천천히 3차원 회전
        const wx = 0.5 * Math.sin(now * 0.8 + d.idleOffset);
        const wy = 0.9;
        const wz = 0.3 * Math.cos(now * 0.7 + d.idleOffset);
        const wLen = Math.hypot(wx, wy, wz);
        if (wLen > 1e-4) {
          const dq = qAxisAngle(wx / wLen, wy / wLen, wz / wLen, wLen * dt);
          d.q = qNorm(qMul(dq, d.q));
        }
      });
      return;
    }

    // PLAY 모드: 바닥면 굴림 물리
    const active = dice.filter(function (d) { return d.selected; });

    active.forEach(function (d) {
      d.scale += (d.targetScale - d.scale) * Math.min(1, dt * 10);
      d.alpha += (d.targetAlpha - d.alpha) * Math.min(1, dt * 10);

      if (d.settled) {
        // 정지 후: 바닥면에 딱 닿아 정면을 향함
        d.q = qSlerp(d.q, d.targetQ, Math.min(1, dt * 14));
        d.z = 0;
        return;
      }

      // 바닥면 위에서의 이동
      d.x += d.vx * dt;
      d.y += d.vy * dt;

      const spd = Math.hypot(d.vx, d.vy);

      // 바닥면을 구를 때 속도에 의해 3차원 회전각이 자연스럽게 결합 (No-slip rolling)
      if (spd > 0.1) {
        const rollRate = 1.0 / (baseRadius * d.scale);
        const rotX = -d.vy * rollRate * dt;
        const rotY = d.vx * rollRate * dt;
        const rotLen = Math.hypot(rotX, rotY);
        if (rotLen > 1e-5) {
          const dq = qAxisAngle(rotX / rotLen, rotY / rotLen, 0, rotLen);
          d.q = qNorm(qMul(dq, d.q));
        }

        // 큐브가 굴러갈 때 모서리가 바닥을 딛는 미세한 높이 리프트 (공중에 뜨는 게 아니라 바닥 접촉 유지)
        // 최대 리프트는 (sqrt(2)-1)*R 수준으로 제한되며 즉시 바닥에 착지
        const liftMax = baseRadius * 0.28;
        d.z = Math.min(liftMax, Math.abs(Math.sin(rotLen * 3.5)) * liftMax * Math.min(1, spd / 300));
      } else {
        d.z = 0;
      }

      // 바닥면 마찰 감쇠
      const friction = Math.pow(0.24, dt);
      d.vx *= friction;
      d.vy *= friction;

      // 스테이지 4면 벽 충돌 (화면에 보여지는 영역에서 튕김)
      const r = baseRadius * d.scale;
      const b = getBounds(r);
      const restitution = 0.78;

      if (d.x < b.left) {
        d.x = b.left;
        d.vx = Math.abs(d.vx) * restitution;
        sfxWall();
        spawnParticles(b.left, d.y, d.palette.bevel, 4);
        spawnWallSpark('left', d.y, d.palette.face);
      } else if (d.x > b.right) {
        d.x = b.right;
        d.vx = -Math.abs(d.vx) * restitution;
        sfxWall();
        spawnParticles(b.right, d.y, d.palette.bevel, 4);
        spawnWallSpark('right', d.y, d.palette.face);
      }

      if (d.y < b.top) {
        d.y = b.top;
        d.vy = Math.abs(d.vy) * restitution;
        sfxWall();
        spawnParticles(d.x, b.top, d.palette.bevel, 4);
        spawnWallSpark('top', d.x, d.palette.face);
      } else if (d.y > height - b.bottom) {
        d.y = height - b.bottom;
        d.vy = -Math.abs(d.vy) * restitution;
        sfxWall();
        spawnParticles(d.x, height - b.bottom, d.palette.bevel, 4);
        spawnWallSpark('bottom', d.x, d.palette.face);
      }

      // 저속 진입 시 깔끔하게 감속
      if (spd < 260) {
        const extraBrake = Math.pow(0.15, dt);
        d.vx *= extraBrake;
        d.vy *= extraBrake;
      }

      // 어느 정도 속도가 줄어들면(spd < 110) 부들부들 떨지 않고 즉시 바닥에 딱 안착하여 바로 확인
      if (spd < 110) {
        d.vx = 0;
        d.vy = 0;
        d.z = 0;
        d.settled = true;
        const topState = getTopAlignedState(d.q);
        d.topFace = topState.face;
        d.targetQ = topState.targetQ;
        d.q = topState.targetQ;
        sfxFloor();
      }
    });

    // 주사위 간 바닥 충돌
    for (let i = 0; i < active.length; i++) {
      for (let j = i + 1; j < active.length; j++) {
        const a = active[i];
        const b = active[j];
        const minDist = baseRadius * (a.scale + b.scale);
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.hypot(dx, dy);
        if (dist > 0 && dist < minDist) {
          const nx = dx / dist, ny = dy / dist;
          const overlap = minDist - dist;
          a.x -= nx * overlap * 0.5;
          a.y -= ny * overlap * 0.5;
          b.x += nx * overlap * 0.5;
          b.y += ny * overlap * 0.5;

          const rvx = b.vx - a.vx;
          const rvy = b.vy - a.vy;
          const vel = rvx * nx + rvy * ny;
          if (vel < 0) {
            const imp = -(1 + 0.72) * vel * 0.5;
            a.vx -= imp * nx;
            a.vy -= imp * ny;
            b.vx += imp * nx;
            b.vy += imp * ny;
            if (Math.abs(imp) > 25) {
              if (a.settled) { a.settled = false; a.targetScale = 1.0; }
              if (b.settled) { b.settled = false; b.targetScale = 1.0; }
              sfxFloor();
              spawnParticles((a.x + b.x) * 0.5, (a.y + b.y) * 0.5, a.palette.bevel, 3);
            }
          }
        }
      }
    }

    if (phase === 'ROLLING' && active.length > 0 && active.every(function (d) { return d.settled; })) {
      onAllSettled();
    }

    if (phase === 'SETTLED' && active.length > 0) {
      smoothSeparateZoomed(active, dt);
    }
  }

  // --- 렌더링: 3D 굴림 & 정지 시 2차원 윗면 표시 ---
  function projectPoint(localPt, d) {
    const r = baseRadius * d.scale;
    const rot = qRotate(localPt, d.q);
    const wx = rot[0] * r;
    const wy = rot[1] * r;
    const wz = rot[2] * r + d.z;

    const camDist = 540;
    const persp = camDist / Math.max(120, camDist - wz);
    const px = Math.round(d.x + wx * persp);
    const py = Math.round(d.y + wy * persp - wz * 0.35);
    return [px, py, rot[2]];
  }

  function drawQuad(pts, fill, stroke, widthPx) {
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) {
      ctx.lineTo(pts[i][0], pts[i][1]);
    }
    ctx.closePath();
    if (fill) {
      ctx.fillStyle = fill;
      ctx.fill();
    }
    if (stroke) {
      ctx.strokeStyle = stroke;
      ctx.lineWidth = widthPx || 1.5;
      ctx.stroke();
    }
  }

  // 회전이 종료되었을 때: 바닥면에 딱 닿아 윗면이 2차원으로 50% 더 크게(3.0배) 확대되어 보여짐
  function render2DDieTop(d) {
    const half = Math.round(baseRadius * d.scale); // 3.0배 확대
    const cx = Math.round(d.x);
    const cy = Math.round(d.y);
    const pal = d.palette;

    // 바닥면 그림자
    ctx.fillStyle = 'rgba(8, 6, 13, 0.45)';
    ctx.fillRect(cx - half + 6, cy - half + 8, half * 2, half * 2);

    // 2차원 주사위 바깥 어두운 픽셀 테두리
    ctx.fillStyle = 'rgb(' + pal.edge.join(',') + ')';
    ctx.fillRect(cx - half, cy - half, half * 2, half * 2);

    // 2차원 주사위 윗면 밝은 베벨 테두리
    const bevelW = Math.max(3, Math.round(half * 0.085));
    ctx.fillStyle = 'rgb(' + pal.bevel.join(',') + ')';
    ctx.fillRect(cx - half + 3, cy - half + 3, (half - 3) * 2, (half - 3) * 2);

    // 2차원 주사위 윗면 본체 색상
    ctx.fillStyle = 'rgb(' + pal.face.join(',') + ')';
    ctx.fillRect(
      cx - half + 3 + bevelW,
      cy - half + 3 + bevelW,
      (half - 3 - bevelW) * 2,
      (half - 3 - bevelW) * 2
    );

    // 2차원 주사위 눈금 (50% 더 커진 3배 크기로 시원시원하게 표시)
    const f = d.topFace || FACES[0];
    const pipSize = Math.max(7, Math.round(half * f.pipR * 1.8));
    const pFill = f.val === 1 ? pal.pipOne : pal.pip;
    const borderCol = f.val === 1 ? '#450a1e' : (pal.id === 'yellow' ? '#ffffff' : '#0c142c');

    f.pips.forEach(function (pip) {
      const px = Math.round(cx + pip[0] * (half * 0.83));
      const py = Math.round(cy + pip[1] * (half * 0.83));
      // 픽셀 눈금 외곽 테두리
      ctx.fillStyle = borderCol;
      ctx.fillRect(px - pipSize * 0.5 - 1.5, py - pipSize * 0.5 - 1.5, pipSize + 3, pipSize + 3);
      // 픽셀 눈금 본체
      ctx.fillStyle = pFill;
      ctx.fillRect(px - pipSize * 0.5, py - pipSize * 0.5, pipSize, pipSize);
    });
  }

  // 굴러가는 중 또는 선택 화면에서의 3차원 렌더링
  function render3DDie(d) {
    const pal = d.palette;
    const isTranslucent = d.alpha < 0.6;

    // 바닥 그림자
    const shadowR = Math.round((baseRadius * d.scale) * (1 + d.z * 0.002));
    ctx.fillStyle = isTranslucent ? 'rgba(8, 6, 13, 0.22)' : 'rgba(8, 6, 13, 0.52)';
    ctx.beginPath();
    ctx.ellipse(d.x, d.y + baseRadius * d.scale * 0.8, shadowR, shadowR * 0.35, 0, 0, Math.PI * 2);
    ctx.fill();

    // 6개 면 깊이 정렬
    const drawFaces = FACES.map(function (f) {
      const wn = qRotate(f.norm, d.q);
      return { f: f, wn: wn, depth: wn[2] };
    }).sort(function (a, b) { return a.depth - b.depth; });

    const lightDir = [-0.35, -0.45, 0.82];

    drawFaces.forEach(function (item) {
      const f = item.f;
      const wn = item.wn;
      const depth = item.depth;

      if (!isTranslucent && depth < -0.05) return;

      const n = f.norm, u = f.u, v = f.v;
      const corners3D = [
        [n[0] - u[0] - v[0], n[1] - u[1] - v[1], n[2] - u[2] - v[2]],
        [n[0] + u[0] - v[0], n[1] + u[1] - v[1], n[2] + u[2] - v[2]],
        [n[0] + u[0] + v[0], n[1] + u[1] + v[1], n[2] + u[2] + v[2]],
        [n[0] - u[0] + v[0], n[1] - u[1] + v[1], n[2] - u[2] + v[2]]
      ];
      const pts2D = corners3D.map(function (p) { return projectPoint(p, d); });

      const ndotl = Math.max(0, wn[0] * lightDir[0] + wn[1] * lightDir[1] + wn[2] * lightDir[2]);
      let rgb = pal.face;
      if (ndotl > 0.7) {
        rgb = [
          Math.min(255, Math.round(pal.face[0] * 0.75 + pal.bevel[0] * 0.25)),
          Math.min(255, Math.round(pal.face[1] * 0.75 + pal.bevel[1] * 0.25)),
          Math.min(255, Math.round(pal.face[2] * 0.75 + pal.bevel[2] * 0.25))
        ];
      } else if (ndotl < 0.35 || depth < 0) {
        rgb = pal.shade;
      }

      const faceAlpha = isTranslucent
        ? (depth < 0 ? d.alpha * 0.35 : d.alpha)
        : d.alpha;

      const fill = 'rgba(' + rgb.join(',') + ',' + faceAlpha.toFixed(3) + ')';
      const edge = isTranslucent
        ? 'rgba(' + pal.bevel.join(',') + ',' + (d.alpha * 1.3).toFixed(3) + ')'
        : 'rgb(' + pal.edge.join(',') + ')';

      drawQuad(pts2D, fill, edge, isTranslucent ? 1 : 2);

      // 안쪽 베벨
      if (depth > 0.12) {
        const ins = 0.82;
        const inner3D = [
          [n[0] + (-u[0] - v[0]) * ins, n[1] + (-u[1] - v[1]) * ins, n[2] + (-u[2] - v[2]) * ins],
          [n[0] + (u[0] - v[0]) * ins,  n[1] + (u[1] - v[1]) * ins,  n[2] + (u[2] - v[2]) * ins],
          [n[0] + (u[0] + v[0]) * ins,  n[1] + (u[1] + v[1]) * ins,  n[2] + (u[2] + v[2]) * ins],
          [n[0] + (-u[0] + v[0]) * ins, n[1] + (-u[1] + v[1]) * ins, n[2] + (-u[2] + v[2]) * ins]
        ];
        const inPts = inner3D.map(function (p) { return projectPoint(p, d); });
        drawQuad(inPts, null, 'rgba(' + pal.bevel.join(',') + ',' + (isTranslucent ? d.alpha * 0.5 : 0.45) + ')', 1);
      }

      // 눈금
      if (depth > -0.15) {
        const s = f.pipR;
        const pipAlpha = isTranslucent ? (depth < 0 ? d.alpha * 0.3 : d.alpha * 1.3) : 1;
        ctx.save();
        ctx.globalAlpha = Math.min(1, pipAlpha);

        f.pips.forEach(function (pip) {
          const pu = pip[0], pv = pip[1];
          const pip3D = [
            [n[0] + u[0] * (pu - s) + v[0] * (pv - s), n[1] + u[1] * (pu - s) + v[1] * (pv - s), n[2] + u[2] * (pu - s) + v[2] * (pv - s)],
            [n[0] + u[0] * (pu + s) + v[0] * (pv - s), n[1] + u[1] * (pu + s) + v[1] * (pv - s), n[2] + u[2] * (pu + s) + v[2] * (pv - s)],
            [n[0] + u[0] * (pu + s) + v[0] * (pv + s), n[1] + u[1] * (pu + s) + v[1] * (pv + s), n[2] + u[2] * (pu + s) + v[2] * (pv + s)],
            [n[0] + u[0] * (pu - s) + v[0] * (pv + s), n[1] + u[1] * (pu - s) + v[1] * (pv + s), n[2] + u[2] * (pu - s) + v[2] * (pv + s)]
          ];
          const pPts = pip3D.map(function (p) { return projectPoint(p, d); });
          const pFill = f.val === 1 ? pal.pipOne : pal.pip;
          drawQuad(pPts, pFill, isTranslucent ? null : '#181425', 1);
        });
        ctx.restore();
      }
    });
  }

  function renderDie(d) {
    // 3번 요구사항: 회전이 종료되면 바닥면이 딱 바닥에 닿아서 윗면이 2차원으로 2배 확대되어 보여짐
    if (mode === 'PLAY' && d.settled) {
      render2DDieTop(d);
    } else {
      render3DDie(d);
    }
  }

  function renderStage() {
    ctx.clearRect(0, 0, width, height);

    // 배경 픽셀 격자
    ctx.fillStyle = '#161224';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#201a33';
    ctx.lineWidth = 1;
    const step = 32;
    ctx.beginPath();
    for (let x = step; x < width; x += step) {
      ctx.moveTo(x, 0); ctx.lineTo(x, height);
    }
    for (let y = step; y < height; y += step) {
      ctx.moveTo(0, y); ctx.lineTo(width, y);
    }
    ctx.stroke();

    // 벽 충돌 스파크
    wallSparks.forEach(function (sp) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, sp.life / 0.18);
      ctx.fillStyle = sp.color;
      const span = 60, th = 8;
      if (sp.side === 'left') ctx.fillRect(10, sp.pos - span * 0.5, th, span);
      else if (sp.side === 'right') ctx.fillRect(width - 10 - th, sp.pos - span * 0.5, th, span);
      else if (sp.side === 'top') ctx.fillRect(sp.pos - span * 0.5, 10, span, th);
      else if (sp.side === 'bottom') ctx.fillRect(sp.pos - span * 0.5, height - 10 - th, span, th);
      ctx.restore();
    });

    // 파티클
    particles.forEach(function (p) {
      ctx.fillStyle = p.color;
      ctx.fillRect(Math.round(p.x), Math.round(p.y), 4, 4);
    });

    // 주사위 렌더링
    const list = mode === 'SELECT'
      ? dice
      : dice.filter(function (d) { return d.selected; });

    list.slice()
      .sort(function (a, b) { return (a.y + a.z * 0.5) - (b.y + b.z * 0.5); })
      .forEach(function (d) { renderDie(d); });
  }

  // --- 스와이프 및 터치 인터랙션 ---
  let pointer = {
    active: false,
    id: null,
    startX: 0,
    startY: 0,
    startTime: 0
  };

  function findDieAt(clientX, clientY) {
    const list = mode === 'SELECT'
      ? dice
      : dice.filter(function (d) { return d.selected; });

    let best = null;
    let minDist = Infinity;
    list.forEach(function (d) {
      const hitR = baseRadius * d.scale * 1.6;
      const dist = Math.hypot(clientX - d.x, clientY - d.y);
      if (dist <= hitR && dist < minDist) {
        minDist = dist;
        best = d;
      }
    });
    return best;
  }

  canvas.addEventListener('pointerdown', function (e) {
    getAudio();
    const x = e.clientX;
    const y = e.clientY;

    if (mode === 'SELECT') {
      const hit = findDieAt(x, y);
      if (hit) {
        toggleDie(hit);
      }
      return;
    }

    // PLAY 모드: 스와이프 시작
    pointer = {
      active: true,
      id: e.pointerId,
      startX: x,
      startY: y,
      startTime: performance.now()
    };
    try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
  });

  function endPointer(e) {
    if (!pointer.active || e.pointerId !== pointer.id) return;

    if (mode === 'PLAY') {
      const dx = e.clientX - pointer.startX;
      const dy = e.clientY - pointer.startY;
      const dist = Math.hypot(dx, dy);
      const dt = Math.max(0.016, (performance.now() - pointer.startTime) * 0.001);

      // 세 주사위 중 하나만 스와이프해도 (또는 화면을 스와이프해도) 모든 주사위가 함께 구름
      if (dist >= 12) {
        rollAllDice({
          vx: dx / dt,
          vy: dy / dt
        });
      } else if (phase === 'SETTLED') {
        // 가볍게 탭한 경우에도 모든 주사위가 함께 구름
        rollAllDice(null);
      }
    }

    pointer.active = false;
  }

  canvas.addEventListener('pointerup', endPointer);
  canvas.addEventListener('pointercancel', endPointer);

  // 버튼 이벤트
  btnPlay.addEventListener('click', function () {
    startPlay();
  });

  btnHome.addEventListener('click', function () {
    returnToSelect();
  });

  // 키보드 지원 (Space: 다시 굴리기, Escape: 메뉴 복귀)
  window.addEventListener('keydown', function (e) {
    if (mode === 'PLAY') {
      if (e.key === 'Escape') {
        returnToSelect();
      } else if (e.key === ' ' || e.key === 'Enter') {
        rollAllDice(null);
      }
    } else if (mode === 'SELECT' && (e.key === 'Enter' || e.key === ' ')) {
      startPlay();
    }
  });

  window.addEventListener('resize', resize);

  // 애니메이션 루프
  let lastTime = performance.now();
  function loop(now) {
    const dt = Math.min(0.033, Math.max(0.001, (now - lastTime) * 0.001));
    lastTime = now;

    updatePhysics(dt);

    ctx.save();
    ctx.scale(dpr, dpr);
    renderStage();
    ctx.restore();

    requestAnimationFrame(loop);
  }

  resize();
  requestAnimationFrame(loop);
})();
