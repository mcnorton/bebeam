function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function uniqueDigits(target) {
  const pool = [];
  for (let i = 0; i <= 9; i++) {
    if (i !== target) pool.push(i);
  }
  shuffle(pool);
  return shuffle([target, pool[0], pool[1]]);
}

export function createClearDialog({ root, board }) {
  const targetEl = root.querySelector('#clear-target');
  const choicesEl = root.querySelector('#clear-choices');
  const feedbackEl = root.querySelector('#clear-feedback');

  let target = 0;
  let closing = false;

  function open() {
    closing = false;
    feedbackEl.hidden = true;
    feedbackEl.textContent = '';
    target = Math.floor(Math.random() * 10);
    targetEl.textContent = String(target);
    choicesEl.replaceChildren();

    for (const n of uniqueDigits(target)) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = String(n);
      btn.addEventListener('click', () => onPick(n));
      choicesEl.appendChild(btn);
    }

    root.hidden = false;
  }

  function closeSoon() {
    closing = true;
    window.setTimeout(() => {
      root.hidden = true;
      closing = false;
    }, 900);
  }

  function onPick(n) {
    if (closing) return;
    if (n === target) {
      board.clear();
      root.hidden = true;
      return;
    }
    feedbackEl.textContent = '취소되었습니다.';
    feedbackEl.hidden = false;
    closeSoon();
  }

  root.addEventListener('click', (e) => {
    if (e.target === root && !closing) {
      feedbackEl.textContent = '취소되었습니다.';
      feedbackEl.hidden = false;
      closeSoon();
    }
  });

  return { open };
}
