const TOOLS = new Set([
  'pen-thin',
  'pen-thick',
  'highlighter',
  'stroke-erase',
  'area-erase',
]);

const AUTO_COLLAPSE_MS = 3000;
const CHEVRON = `<svg viewBox="0 0 32 32" aria-hidden="true"><path class="ln chevron" d="M13 8l8 8-8 8" stroke-width="2.6"/></svg>`;

export function createToolbar({ root, board, onClear }) {
  const buttons = [...root.querySelectorAll('[data-tool]')];
  const toggleBtn = root.querySelector('[data-action="toggle"]');
  let timer = 0;

  function activeToolBtn() {
    return buttons.find((btn) => btn.classList.contains('is-active')) || buttons[0];
  }

  function paintToggle(collapsed) {
    if (!toggleBtn) return;
    if (collapsed) {
      const src = activeToolBtn();
      toggleBtn.innerHTML = src.innerHTML;
      toggleBtn.classList.add('is-active');
      const name = src.getAttribute('aria-label') || '도구';
      toggleBtn.title = `${name} · 펼치기`;
      toggleBtn.setAttribute('aria-label', `도구 펼치기 (${name})`);
    } else {
      toggleBtn.innerHTML = CHEVRON;
      toggleBtn.classList.remove('is-active');
      toggleBtn.title = '도구 접기';
      toggleBtn.setAttribute('aria-label', '도구 접기');
    }
  }

  function syncActive(tool) {
    for (const btn of buttons) {
      const active = btn.dataset.tool === tool;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', active ? 'true' : 'false');
    }
    paintToggle(root.classList.contains('is-collapsed'));
  }

  function setCollapsed(collapsed) {
    clearTimeout(timer);
    root.classList.toggle('is-collapsed', collapsed);
    root.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
    paintToggle(collapsed);
    if (!collapsed) timer = setTimeout(() => setCollapsed(true), AUTO_COLLAPSE_MS);
  }

  board.canvas.addEventListener('pointerdown', () => {
    if (!root.classList.contains('is-collapsed')) setCollapsed(true);
  });

  root.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn || !root.contains(btn)) return;

    if (btn.dataset.action === 'toggle') {
      setCollapsed(!root.classList.contains('is-collapsed'));
      return;
    }
    if (btn.dataset.action === 'undo') {
      board.undo();
      return;
    }
    if (btn.dataset.action === 'redo') {
      board.redo();
      return;
    }
    if (btn.dataset.action === 'clear') {
      setCollapsed(true);
      onClear();
      return;
    }

    const tool = btn.dataset.tool;
    if (!TOOLS.has(tool)) return;
    board.setTool(tool);
    syncActive(tool);
    setCollapsed(false);
  });

  syncActive(board.getTool());
  paintToggle(root.classList.contains('is-collapsed'));
}
