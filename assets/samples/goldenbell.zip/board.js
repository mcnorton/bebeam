// Baseline widths are tuned for a ~700px short side (typical tablet).
export const BASE_PEN_THIN = 6;
export const BASE_PEN_THICK = 16;
export const BASE_HIGHLIGHTER = BASE_PEN_THICK * 4;
export const BASE_AREA_ERASE = 44;
export const BASE_HIT_PAD = 20;
export const BASE_SHORT = 700;
export const HISTORY_LIMIT = 40;

const INK = '#111111';
const HIGHLIGHT = '#ffd60a';

/**
 * @typedef {{x:number,y:number}} Pt
 * @typedef {{ kind: 'pen'|'highlighter', width: number, color: string, points: Pt[],
 *   box: {minX:number,minY:number,maxX:number,maxY:number} }} Stroke
 */

const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });

function distToSegment(p, a, b) {
  const abx = b.x - a.x;
  const aby = b.y - a.y;
  const len2 = abx * abx + aby * aby;
  let t = len2 ? ((p.x - a.x) * abx + (p.y - a.y) * aby) / len2 : 0;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p.x - (a.x + t * abx), p.y - (a.y + t * aby));
}

function makeStroke(cfg, points) {
  const s = { kind: cfg.kind, width: cfg.width, color: cfg.color, points: [], box: null };
  for (const p of points) addPoint(s, p);
  return s;
}

function addPoint(s, p) {
  const pts = s.points;
  const last = pts[pts.length - 1];
  if (last && Math.abs(p.x - last.x) < 0.5 && Math.abs(p.y - last.y) < 0.5) return false;
  pts.push(p);
  const b = s.box;
  if (!b) s.box = { minX: p.x, minY: p.y, maxX: p.x, maxY: p.y };
  else {
    if (p.x < b.minX) b.minX = p.x;
    if (p.x > b.maxX) b.maxX = p.x;
    if (p.y < b.minY) b.minY = p.y;
    if (p.y > b.maxY) b.maxY = p.y;
  }
  return true;
}

function boxNear(box, a, b, reach) {
  return Math.max(a.x, b.x) + reach >= box.minX && Math.min(a.x, b.x) - reach <= box.maxX
    && Math.max(a.y, b.y) + reach >= box.minY && Math.min(a.y, b.y) - reach <= box.maxY;
}

function drawStroke(ctx, s) {
  const pts = s.points;
  const n = pts.length;
  ctx.strokeStyle = s.color;
  ctx.lineWidth = s.width;
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  if (n === 1) {
    ctx.lineTo(pts[0].x + 0.01, pts[0].y);
  } else {
    for (let i = 1; i < n; i++) {
      const m = mid(pts[i - 1], pts[i]);
      if (i === 1) ctx.lineTo(m.x, m.y);
      else ctx.quadraticCurveTo(pts[i - 1].x, pts[i - 1].y, m.x, m.y);
    }
    ctx.lineTo(pts[n - 1].x, pts[n - 1].y);
  }
  ctx.stroke();
}

function keepAbove(s, limit) {
  const chunks = [];
  let buf = [];
  for (const p of s.points) {
    if (p.y <= limit) buf.push(p);
    else if (buf.length) {
      chunks.push(buf);
      buf = [];
    }
  }
  if (buf.length) chunks.push(buf);
  return chunks.map((c) => makeStroke(s, c));
}

export function createBoard({ hlCanvas, inkCanvas, nameZone, onHistoryChange }) {
  const hlCtx = hlCanvas.getContext('2d', { alpha: true, desynchronized: true });
  const inkCtx = inkCanvas.getContext('2d', { alpha: true, desynchronized: true });

  /** @type {Stroke[]} */
  let inkStrokes = [];
  /** @type {Stroke[]} */
  let hlStrokes = [];
  let tool = 'pen-thin';
  let origin = { left: 0, top: 0 };
  let cssW = 0;
  let cssH = 0;
  let strokeScale = 1;
  let eraseRadius = BASE_AREA_ERASE;
  let hitPad = BASE_HIT_PAD;
  let eraseSample = 8;

  /** @type {Map<number, any>} */
  const active = new Map();
  let strokeEraseQueue = [];
  let areaEraseQueue = [];
  let frame = 0;
  let eraseDirty = false;

  /** @type {{ink:Stroke[], hl:Stroke[]}[]} */
  const undoStack = [];
  /** @type {{ink:Stroke[], hl:Stroke[]}[]} */
  const redoStack = [];

  function penConfig(name) {
    if (name === 'pen-thin') return { kind: 'pen', width: BASE_PEN_THIN * strokeScale, color: INK };
    if (name === 'pen-thick') return { kind: 'pen', width: BASE_PEN_THICK * strokeScale, color: INK };
    if (name === 'highlighter') return { kind: 'highlighter', width: BASE_HIGHLIGHTER * strokeScale, color: HIGHLIGHT };
    return null;
  }

  function applyScale(next) {
    const ratio = next / strokeScale;
    if (Math.abs(ratio - 1) < 0.02) {
      strokeScale = next;
      eraseRadius = BASE_AREA_ERASE * strokeScale;
      hitPad = BASE_HIT_PAD * strokeScale;
      eraseSample = Math.max(6, 8 * strokeScale);
      return;
    }
    for (const s of inkStrokes) s.width *= ratio;
    for (const s of hlStrokes) s.width *= ratio;
    for (const st of active.values()) {
      if (st.stroke) st.stroke.width *= ratio;
    }
    for (const snap of undoStack) {
      for (const s of snap.ink) s.width *= ratio;
      for (const s of snap.hl) s.width *= ratio;
    }
    for (const snap of redoStack) {
      for (const s of snap.ink) s.width *= ratio;
      for (const s of snap.hl) s.width *= ratio;
    }
    strokeScale = next;
    eraseRadius = BASE_AREA_ERASE * strokeScale;
    hitPad = BASE_HIT_PAD * strokeScale;
    eraseSample = Math.max(6, 8 * strokeScale);
  }

  const ctxFor = (s) => (s.kind === 'highlighter' ? hlCtx : inkCtx);
  const listFor = (s) => (s.kind === 'highlighter' ? hlStrokes : inkStrokes);

  function snapshot() {
    return { ink: inkStrokes.slice(), hl: hlStrokes.slice() };
  }

  function notifyHistory() {
    onHistoryChange?.({
      canUndo: undoStack.length > 0,
      canRedo: redoStack.length > 0,
    });
  }

  function beforeChange() {
    undoStack.push(snapshot());
    if (undoStack.length > HISTORY_LIMIT) undoStack.shift();
    redoStack.length = 0;
    notifyHistory();
  }

  function restore(snap) {
    inkStrokes = snap.ink.slice();
    hlStrokes = snap.hl.slice();
    active.clear();
    strokeEraseQueue = [];
    areaEraseQueue = [];
    redrawAll();
    notifyHistory();
  }

  function undo() {
    if (!undoStack.length) return;
    finishAll();
    redoStack.push(snapshot());
    restore(undoStack.pop());
  }

  function redo() {
    if (!redoStack.length) return;
    finishAll();
    undoStack.push(snapshot());
    restore(redoStack.pop());
  }

  function resize() {
    const r = inkCanvas.getBoundingClientRect();
    origin = { left: r.left, top: r.top };
    cssW = r.width;
    cssH = r.height;
    // Grow with the shorter screen edge so large tablets/TVs stay bold.
    const next = Math.min(2.6, Math.max(0.9, Math.min(cssW, cssH) / BASE_SHORT));
    applyScale(next);
    const scale = Math.min(window.devicePixelRatio || 1, 2);
    for (const [c, ctx] of [[hlCanvas, hlCtx], [inkCanvas, inkCtx]]) {
      c.width = Math.max(1, Math.round(cssW * scale));
      c.height = Math.max(1, Math.round(cssH * scale));
      ctx.setTransform(scale, 0, 0, scale, 0, 0);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }
    redrawAll();
  }

  function redrawAll() {
    hlCtx.clearRect(0, 0, cssW, cssH);
    inkCtx.clearRect(0, 0, cssW, cssH);
    for (const s of hlStrokes) drawStroke(hlCtx, s);
    for (const s of inkStrokes) drawStroke(inkCtx, s);
    for (const st of active.values()) {
      if (!st.stroke) continue;
      drawStroke(ctxFor(st.stroke), st.stroke);
      st.drawn = st.stroke.points.length - 1;
    }
  }

  function drawLive(st) {
    const s = st.stroke;
    const pts = s.points;
    const n = pts.length;
    if (st.drawn >= n - 1) return;
    const ctx = ctxFor(s);
    ctx.strokeStyle = s.color;
    ctx.lineWidth = s.width;
    ctx.beginPath();
    for (let i = st.drawn + 1; i < n; i++) {
      const p = pts[i - 1];
      const m = mid(p, pts[i]);
      if (i === 1) {
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(m.x, m.y);
      } else {
        if (i === st.drawn + 1) {
          const a = mid(pts[i - 2], p);
          ctx.moveTo(a.x, a.y);
        }
        ctx.quadraticCurveTo(p.x, p.y, m.x, m.y);
      }
    }
    ctx.stroke();
    st.drawn = n - 1;
  }

  function drawTail(st) {
    const pts = st.stroke.points;
    const n = pts.length;
    if (n < 2) return;
    const ctx = ctxFor(st.stroke);
    const m = mid(pts[n - 2], pts[n - 1]);
    ctx.strokeStyle = st.stroke.color;
    ctx.lineWidth = st.stroke.width;
    ctx.beginPath();
    ctx.moveTo(m.x, m.y);
    ctx.lineTo(pts[n - 1].x, pts[n - 1].y);
    ctx.stroke();
  }

  function point(e) {
    return { x: e.clientX - origin.left, y: e.clientY - origin.top };
  }

  function finish(id, record) {
    const st = active.get(id);
    if (!st) return;
    active.delete(id);
    if (!st.stroke) {
      if (st.erase && eraseDirty && record && st.before) {
        undoStack.push(st.before);
        if (undoStack.length > HISTORY_LIMIT) undoStack.shift();
        redoStack.length = 0;
        notifyHistory();
      }
      eraseDirty = false;
      return;
    }
    drawTail(st);
    if (record) beforeChange();
    listFor(st.stroke).push(st.stroke);
  }

  function finishAll() {
    for (const id of [...active.keys()]) finish(id, true);
  }

  // Keep already-drawn finger ink; only stop new touches while a stylus is down.
  function rejectTouches() {
    for (const [id, st] of active) {
      if (st.type === 'touch') finish(id, true);
    }
  }

  function penIsDown() {
    for (const st of active.values()) if (st.type === 'pen') return true;
    return false;
  }

  function scheduleErase() {
    if (!frame) frame = requestAnimationFrame(flushErase);
  }

  function flushErase() {
    frame = 0;
    if (strokeEraseQueue.length) {
      const q = strokeEraseQueue;
      strokeEraseQueue = [];
      if (eraseStrokes(q)) eraseDirty = true;
    }
    if (areaEraseQueue.length) {
      const q = areaEraseQueue;
      areaEraseQueue = [];
      eraseArea(q);
      eraseDirty = true;
    }
  }

  function strokeHits(s, p) {
    const pad = s.width / 2 + hitPad;
    const b = s.box;
    if (p.x < b.minX - pad || p.x > b.maxX + pad || p.y < b.minY - pad || p.y > b.maxY + pad) return false;
    const pts = s.points;
    if (pts.length === 1) return Math.hypot(p.x - pts[0].x, p.y - pts[0].y) <= pad;
    for (let i = 1; i < pts.length; i++) {
      if (distToSegment(p, pts[i - 1], pts[i]) <= pad) return true;
    }
    return false;
  }

  function eraseStrokes(segs) {
    const samples = [];
    for (let i = 0; i < segs.length; i += 2) {
      const a = segs[i];
      const b = segs[i + 1];
      const steps = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / eraseSample));
      for (let k = 0; k <= steps; k++) {
        samples.push({ x: a.x + (b.x - a.x) * k / steps, y: a.y + (b.y - a.y) * k / steps });
      }
    }
    const gone = new Set();
    for (const p of samples) {
      const ink = inkStrokes.filter((s) => !gone.has(s) && strokeHits(s, p));
      const hits = ink.length ? ink : hlStrokes.filter((s) => !gone.has(s) && strokeHits(s, p));
      for (const s of hits) gone.add(s);
    }
    if (!gone.size) return false;
    inkStrokes = inkStrokes.filter((s) => !gone.has(s));
    hlStrokes = hlStrokes.filter((s) => !gone.has(s));
    redrawAll();
    return true;
  }

  function eraseArea(segs) {
    const r = eraseRadius;
    for (const ctx of [inkCtx, hlCtx]) {
      ctx.save();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.lineWidth = r * 2;
      ctx.beginPath();
      for (let i = 0; i < segs.length; i += 2) {
        ctx.moveTo(segs[i].x, segs[i].y);
        ctx.lineTo(segs[i + 1].x + 0.01, segs[i + 1].y);
      }
      ctx.stroke();
      ctx.restore();
    }
    inkStrokes = inkStrokes.flatMap((s) => cut(s, segs, r));
    hlStrokes = hlStrokes.flatMap((s) => cut(s, segs, r));
  }

  function cut(s, segs, r) {
    const reach = r + s.width / 2;
    const near = [];
    for (let i = 0; i < segs.length; i += 2) {
      if (boxNear(s.box, segs[i], segs[i + 1], reach)) near.push(segs[i], segs[i + 1]);
    }
    if (!near.length) return [s];

    const step = reach / 3;
    const chunks = [];
    let buf = [];
    let touched = false;
    const visit = (q) => {
      let hit = false;
      for (let i = 0; i < near.length && !hit; i += 2) hit = distToSegment(q, near[i], near[i + 1]) <= reach;
      if (hit) {
        touched = true;
        if (buf.length) chunks.push(buf);
        buf = [];
      } else {
        buf.push(q);
      }
    };
    const pts = s.points;
    visit(pts[0]);
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1];
      const b = pts[i];
      const steps = Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / step);
      for (let k = 1; k <= steps; k++) visit({ x: a.x + (b.x - a.x) * k / steps, y: a.y + (b.y - a.y) * k / steps });
    }
    if (buf.length) chunks.push(buf);
    if (!touched) return [s];
    return chunks.map((c) => makeStroke(s, c));
  }

  function onPointerDown(e) {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    if (e.pointerType === 'touch' && penIsDown()) return;
    e.preventDefault();
    if (e.pointerType === 'pen') rejectTouches();

    // Fast lift/down reuses the same pointerId before pointerup — save the old stroke first.
    if (active.has(e.pointerId)) finish(e.pointerId, true);

    try { inkCanvas.setPointerCapture(e.pointerId); } catch { /* not capturable */ }

    const p = point(e);
    const cfg = penConfig(tool);
    if (cfg) {
      const st = { type: e.pointerType, stroke: makeStroke(cfg, [p]), drawn: 0 };
      active.set(e.pointerId, st);
      drawStroke(ctxFor(st.stroke), st.stroke);
      return;
    }
    eraseDirty = false;
    active.set(e.pointerId, { type: e.pointerType, erase: true, last: p, before: snapshot() });
    (tool === 'stroke-erase' ? strokeEraseQueue : areaEraseQueue).push(p, p);
    scheduleErase();
  }

  function onPointerMove(e) {
    const st = active.get(e.pointerId);
    if (!st) return;
    const coalesced = typeof e.getCoalescedEvents === 'function' ? e.getCoalescedEvents() : [];
    const events = coalesced.length ? coalesced : [e];

    if (st.stroke) {
      for (const ev of events) addPoint(st.stroke, point(ev));
      drawLive(st);
      return;
    }
    const queue = tool === 'stroke-erase' ? strokeEraseQueue : areaEraseQueue;
    for (const ev of events) {
      const p = point(ev);
      queue.push(st.last, p);
      st.last = p;
    }
    scheduleErase();
  }

  function onPointerEnd(e) {
    finish(e.pointerId, true);
  }

  inkCanvas.addEventListener('pointerdown', onPointerDown);
  // Extra points some browsers only expose here — keeps fast strokes connected.
  if (window.PointerEvent && 'onpointerrawupdate' in window) {
    inkCanvas.addEventListener('pointerrawupdate', onPointerMove);
  }
  window.addEventListener('pointermove', onPointerMove);
  window.addEventListener('pointerup', onPointerEnd);
  window.addEventListener('pointercancel', onPointerEnd);
  inkCanvas.addEventListener('lostpointercapture', (e) => {
    // Capture can drop mid-stroke on some tablets; keep the ink that was already drawn.
    if (active.has(e.pointerId)) finish(e.pointerId, true);
  });
  inkCanvas.addEventListener('contextmenu', (e) => e.preventDefault());
  window.addEventListener('resize', resize);
  resize();
  notifyHistory();

  return {
    canvas: inkCanvas,
    setTool(next) {
      finishAll();
      tool = next;
    },
    getTool: () => tool,
    undo,
    redo,
    canUndo: () => undoStack.length > 0,
    canRedo: () => redoStack.length > 0,
    clear() {
      finishAll();
      beforeChange();
      active.clear();
      strokeEraseQueue = [];
      areaEraseQueue = [];
      const limit = nameZone.offsetHeight;
      inkStrokes = inkStrokes.flatMap((s) => keepAbove(s, limit));
      hlStrokes = hlStrokes.flatMap((s) => keepAbove(s, limit));
      redrawAll();
    },
  };
}
