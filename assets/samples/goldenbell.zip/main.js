import { createBoard } from './board.js';
import { createToolbar } from './toolbar.js';
import { createClearDialog } from './clear-dialog.js';

const undoBtn = document.querySelector('[data-action="undo"]');
const redoBtn = document.querySelector('[data-action="redo"]');

function syncHistory({ canUndo, canRedo }) {
  undoBtn.disabled = !canUndo;
  redoBtn.disabled = !canRedo;
}

const board = createBoard({
  hlCanvas: document.getElementById('hl-layer'),
  inkCanvas: document.getElementById('ink-layer'),
  nameZone: document.getElementById('name-zone'),
  onHistoryChange: syncHistory,
});

const dialog = createClearDialog({
  root: document.getElementById('clear-dialog'),
  board,
});

createToolbar({
  root: document.getElementById('toolbar'),
  board,
  onClear: () => dialog.open(),
});
